from .utils import load_dataset as _load_dataset

# Load FOREX datasets
DOGEUSDT = _load_dataset('DOGEUSDT')
